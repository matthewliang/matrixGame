

/**
 * The different screens the user can be on.
 * @author Matt
 *
 */
public enum State {
	MENU, PLAYING, GAMEOVER, HIGHSCORESCREEN, INSTRUCTIONSCREEN;
}
